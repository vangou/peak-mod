# FireFixes


This Mod Removes flowers on the top of the peak, it will boost your performance up by almost 50%,

--------------------

Manual installation:

1. Install BepInEx

2. Download this mod and place the LavaLagPatches.dll in the BepInEx\Plugins folder
