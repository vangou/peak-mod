# PEAK Save Manager

Save and Load your PEAK runs, with friends!

## Installation

Drag and drop the PeakSaveManager.dll file into your PEAK BepInEx plugins folder.

## Usage

To save a run, press `F10` on the keyboard and click either `Quick Save` or set a name for your run and click `Save`.

Your inventory and position will be saved, along with character status effects and other information regarding your run.

# WARNING

Not tested with friends yet, only solo in a Hosted server. If it works with friends, please let me know!