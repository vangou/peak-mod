Hungry for S'more? Adds nine new skin colors! 

Colors Added:
Firebrick
Baby Blue
Teal
Coral Pink
Lavender
Mint Green
Vanilla
Chocolate
Strawberry
...I started getting hungry towards the end...

Credit for code goes to MoreColourOptions mod by CakeDevs(Made by Cake, Marco, Gouda and Rush). 