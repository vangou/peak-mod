# Changelog

## 1.0.0
- Initial release
- Numbers/Percentages for stamina and status effects
- Config options for font size, outline thickness, and percentage sign