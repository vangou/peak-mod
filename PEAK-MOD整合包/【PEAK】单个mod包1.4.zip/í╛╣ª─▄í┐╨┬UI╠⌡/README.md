# StaminaStats
A simple mod for PEAK that displays numbers or percentages for your stamina and status effects.

![enter image description here](https://cdn.discordapp.com/attachments/1205661875518439486/1387060904125796544/image.png?ex=685bf8a1&is=685aa721&hm=8065fd348b4a702bf641c0386cee5fa26912b2e5ee6dedad50c7ee3ed5d752bb&)
## Features
- Shows values for stamina and afflictions
- Configurable font and outline sizes 
- Option to show percent signs