# v1.1.0
- Added: You can now access the backpack of someone you're carrying
- Fixed: You no longer can access your backpack while passed out or dead

# v1.0.1
- Updated Thunderstore dependencies

# v1.0.0
- Initial Release 🔥