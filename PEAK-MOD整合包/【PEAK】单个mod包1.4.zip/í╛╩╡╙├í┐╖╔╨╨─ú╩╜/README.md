
I needed a fly mode to quickly test some features and create another mod, so I’m sharing it in case you need it too!

--------------------

- Press F6 to activate, and press it again to deactivate.
- Jump to go up
- Crouch to go down

You should be able to move around using the standard movement controls.
Let me know if that’s not the case (I tested it with an AZERTY keyboard).

--------------------

Manual installation:

1. Install BepInEx
2. Download this mod and place the FlyMod.dll in the BepInEx\Plugins folder
