### 2.3.2

- README changes as wording was confusing some people

### 2.3.1

- Add a host check and change get ground method

### 2.3.0

- Change the method of setting max player count so that its more compatible with things like the new lobby privacy settings

### 2.2.3

- Removes a test spawn marshmallow Keybind I mistakenly forgot to remove from the prior release.
- Add link to PeakUnlimitedEndScreen mod by kaosz in readme

### 2.2.2

- Rewrite the marshmallow code to be more reliable.
- Restore config option to set a desired amount of marshmallows.

### 2.2.1

- Revert 2.2.0, back to 2.1.1 (2.2.0 broke extra marshmallows, will fix 2.2.0 in 2.2.2)

### 2.2.0

- Removes some debug stuff
- Adds a configuration setting to cheat in even more marshmallows!

### 2.1.1

- Accidentally left debug +20 marshmallows in 2.1.0, this fixes that. Now the correct amount of marshmallows will spawn. Sorry, I pulled an all nighter testing the marshmallow stuff!

### 2.1.0

- Added rotation to marshmallows for nicer visual effect
- Added a changelog

### 2.0.0 (Marshmallows!)

- Added configurable extra marshmallows for the additional players

### 1.3.0

- Edited the max player cap to lessen strain on servers

### 1.0.0 - 1.2.7

- Various README improvements
- Images
- Icon updates
- BepInEx version change
- A couple minor code changes