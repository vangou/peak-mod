# EasyBackpack
Are you tired of having to drop your backpack to access it? No need to worry, you don't have to anymore!  
Using a custom keybind *(see below)* you can access your backpack without having to drop it!

### Configuration
The default keybind for accessing your backpack is **B**, although you can edit it here:
- <steam directory>\PEAK\BepInEx\config\nickklmao.EasyBackpack.cfg


## Support
- If you have any questions or concerns you can contact me through the [peak modding Discord server!](https://discord.gg/SAw86z24rB) - @nickklmao
  - If the Discord link doesn't work then check the top left of the [thunderstore website (for peak)](https://thunderstore.io/c/peak/).
