This mod fixes the end screen for more player mods (Tested with Unlimited)

Manual Download:
Drop PEAK_FixMorePlayerEndScreen.dll into <yourgame>/BepInEx/plugins


