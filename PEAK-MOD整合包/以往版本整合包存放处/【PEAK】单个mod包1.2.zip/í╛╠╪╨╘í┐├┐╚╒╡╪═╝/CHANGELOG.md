# Changelog

## 1.7.0
- New GUI to show current level config
- Config options to disable GUIs

## 1.6.2
- Adds GitHub

## 1.6.1
- Fixes Memory Leakage (Sorry for this)

## 1.6.0
- Allows for lists in config (EX: Level_0,Level_1)


## 1.0.0, 1.5.0, 1.5.1
- Works
- Ability to select 'Random' or a specific level
