# v1.0.1
- Manifest and Readme changes. No actual changes to the mod itself.

# v1.0.0
- Initial Release
