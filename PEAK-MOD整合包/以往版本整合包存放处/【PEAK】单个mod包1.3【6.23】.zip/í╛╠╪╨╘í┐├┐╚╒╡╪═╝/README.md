**This mod removes the daily wait timer for new maps, and instead loads a new map every time you start a round!**

*Configurable in BepInEx/config/com.smckeen.morepeak.cfg*

**INSTALLATION INSTRUCTIONS**
1. Download BepInEx & Extract All from BepInEx ZIP archive to new folder (anywhere - just know where it is)
2. Find PEAK Installation: Steam -> PEAK -> Manage -> Browse Local Files
3. Copy all CONTENTS of the extracted folder (not the folder) into the PEAK folder
4. Run Game to Generate plugins/extra folders
5. Go to BepInEx -> plugins
6. Drop in the MorePeak.dll to the plugins folder
7. Run PEAK

(Configuration Options can be found in BepInEx -> config -> com.smckeen.morepeak.cfg)
