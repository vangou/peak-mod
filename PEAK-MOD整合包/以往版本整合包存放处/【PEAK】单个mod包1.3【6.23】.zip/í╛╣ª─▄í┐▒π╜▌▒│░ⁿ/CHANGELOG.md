# v1.0.1
- Updated Thunderstore dependencies

# v1.0.0
- Initial Release 🔥