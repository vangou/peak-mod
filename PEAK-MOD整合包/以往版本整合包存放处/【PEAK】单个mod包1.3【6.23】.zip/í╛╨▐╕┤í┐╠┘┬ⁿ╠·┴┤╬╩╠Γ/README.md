# PEAK Vine FIX

This patch fixes the rubberbanding when using the vines or chains during multiplayer

## Manual Installation
Only the host needs to install!

1.) Download Bepinex from [here](https://github.com/BepInEx/BepInEx/releases/download/v5.4.23.3/BepInEx_win_x64_5.4.23.3.zip) <br>
2.) Extract the contents of that zip into your game directory (default: C:\Program Files (x86)\Steam\steamapps\common\PEAK) resulting in a folder that has the following files: <br>
![image](https://github.com/user-attachments/assets/403d9a1d-16a4-409c-a046-bc56141ac0ca) <br>
3.) Start the game and close it again, this does the first time set up for Bepinex. <br>
4.) Navigate to ...\PEAK\BepInEx\plugins, copy and paste the VineClimbFix.dll from the patch files into this folder. <br>
5.) Run the game <br>

## Important
- Im not updating this mod in the future so no contacting regarding issues or bugs
