
Just a simple mod to make the stamina infinite. 

It’s my first mod, made to learn how modding works, all thanks to [CoddingCat](https://thunderstore.io/c/peak/p/CoddingCat/) who taught me how to do it !

--------------------

Manual installation:

1. Install BepInEx
2. Download this mod and place the InfiniteStamina.dll in the BepInEx\Plugins folder
