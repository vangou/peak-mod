Hello! There's no fall damage now.

New feature in 1.1.0, there's now a config file where u can configure this:
PassOut:
- If true, you WILL pass out for a brief moment when you would've taken fall damage.
- If false, you WON'T pass out when you would've taken fall damage.
This doesn't affect the fall damage cancelation, it always removes it.